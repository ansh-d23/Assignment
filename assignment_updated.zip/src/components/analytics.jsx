import React from "react";
import DeviceType from './DeviceType.jsx'
import ActiveUsers from "./ActiveUsers.jsx";

const Analytics = () => {

    return (
        <>
        <DeviceType/>
        <ActiveUsers/>
        </>
    );
};

export default Analytics